#!/usr/bin/env python
#Prototype for attacker model framework and example models
# Marco+Nils, SUTD, 2015

import copy
import sys
import os
import json
import glob
import re
import numpy

#CONSTANTS
BIBFILE_LOCATION = "../bibs/"
BIBFILE = "bibliography.bib"
ATTACKER_PROFILES_DIR="attackerModels"
ATTACKER_PROFILES_DIR_PATH="./"
LITERATURE_DIR="literature"
LITERATURE_DIR_PATH="./"

# Root of the attacker model tree
class AttackerTree():
    def __init__(self, name):
        self.name=name
        self.name=name
        self.children={}
	self.default=0
	self.description=""
	self.bibentry=""
	self.filename=""
	self.mapping=""

    def __repr__(self, level=0):
	if self.default == 1:
	        ret = "\tname: "*level+self.name+"\n"
	        ret += "\tdescription: "*level+self.description+"\n\n"
	        ret += "\tbibentry: "*level+self.bibentry+"\n"
	        ret += "\tmapping: "*level+self.mapping+"\n\n"
        	for child in self.children.keys():
	            ret += self.children[child].printAttackerModel(level+1)
	else:
	        ret = "\tname: "*level+self.name+"\n"
	        ret += "\tdescription: "*level+self.description+"\n\n"
	        ret += "\tbibentry: "*level+self.bibentry+"\n"
	        ret += "\tmapping: "*level+self.mapping+"\n\n"
        	for child in self.children.keys():
	            ret += self.children[child].__repr__(level+1)
        
	return ret

    def printAsJson(self, level=0):
	ret = "{"+"\t"*level+"\n\t\"name\": \""+self.name+"\",\n"
	ret += "\t"*level+"\t\"description\": "+json.dumps(self.description)+",\n"
	ret += "\t"*level+"\t\"bibentry\": \""+self.bibentry+"\",\n"
	ret += "\t"*level+"\t\"mapping\": \""+self.mapping+"\",\n"
	ret += "\t"*level+"\t\"children\": [\n"
	childNumber=0
        for child in self.children.keys():
	    ret+="\t"*level+" {\n"
	    ret += self.children[child].printAsJson(level+1)
	    if len(self.children)-1 == childNumber:
		ret += "\t"*level+"} \n"
	    else:
		ret += "\t"*level+"},\n"
	    childNumber += 1

	ret+="\n"+"\t"*level+"\t]\n"
	ret+="\n}\n"
	return ret

    def addChild(self, obj):
        self.children[obj.name]=obj

    #create the new attacker as a deepCopy of the one passed as argument
    def createStatic(self, AttackerTree):
	for child in AttackerTree.children.values():
	   childNode=copy.deepcopy(child)
	   childNode.setFirstMetric()
	   self.addChild(childNode)

    #create the new attacker
    def createInteractive(self, AttackerTree):
	for child in AttackerTree.children.values():
#	    print "Do you want to define subdimensions of "+child.name+" ? (Y/n)"
#	    def_subdimension=raw_input()
#	    if def_subdimension.lower() == "y" or def_subdimension == "":
#    	        child.createInteractive(self)
#	    else:
#		print "Choose value for "+child.name+": "+repr(child.metric)
#		dimension_value=raw_input()
	    #copy each node
	    childNode=copy.deepcopy(child)
	    path=""
	    #call create interactive to set values of leaves
	    childNode.createInteractive(AttackerTree,path)
	    self.addChild(childNode)
	    
	#call sanitize to add values to internal node of the attacker tree
	self.calculateInternalMetrics()
	    
    def createFromJson(self, jsonData):
	for child in jsonData['children']:
	    dimensionNode=DimensionNode(child['name'])
	    dimensionNode.description=child['description']
	    dimensionNode.metric=child['metric']
	    dimensionNode.uniqueID=child['uniqueID']
	    dimensionNode.metricType=listOfMetrics[listOfMetrics.index(child['metricType'])]
	    self.addChild(dimensionNode)
	    #for nestedChild in child['children']:
	    if len(child['children']) != 0:
		dimensionNode.createFromJson(child)
	    
    def countSubTreeMetrics(self):
	ret=0
        for child in self.children.keys():
            ret += self.children[child].countSubTreeMetrics()
        return ret

    #return the value (the metric) of a dimension 
    def getValueOfDimension(self,dimension):
	ret=""
        for child in self.children.keys():
            ret = self.children[child].getValueOfDimension(dimension)
	    if ret != "":
		return ret
        return ret

    #returns all the dimensions of an attacker profile
    #the structured returned is a list [name,depth]
    def getDimensions(self):
	depth=0
	dimensions=[]
        for child in self.children.keys():
            self.children[child].getDimensions(dimensions,depth)
	return dimensions 

    #set dimension mod_dimension (interactively) 
    def setDimension(self,mod_dimension):
	ret=0
        for child in self.children.keys():
            ret += self.children[child].setDimension(mod_dimension,"")
	return ret

    #calculate father's metric as the average of the childs' metrics
    def calculateInternalMetrics(self):
        for child in self.children.keys():
	   self.children[child].calculateInternalMetrics()


    #saves an filetype file
    #filetype={json}
    #currently only json
    def saveTofile(self, filetype):
	self.filename=ATTACKER_PROFILES_DIR_PATH+ATTACKER_PROFILES_DIR+"/"+self.name+"."+filetype
	while os.path.isfile(self.filename) == True:
	    print "file "+self.filename+" already exists, please provide another name (without extension)"
	    filenameTemp=raw_input()
	    self.filename=ATTACKER_PROFILES_DIR_PATH+ATTACKER_PROFILES_DIR+"/"+filenameTemp+"."+filetype
	f=open(self.filename,'w')
	if filetype == "json":
	    f.write(self.printAsJson())
	else:
	    print "filetype: "+filetype+" not supported"
	f.close()

    #compares a profile with self
    #by calculating the euclidean distance between the two vectors representing the two profiles
    #the dimensionality is equal to the number of dimensions
    #the formula for Euclidean distance between two points p,q in a n-dimensional space is the following
    #sqrt(sum((p1-q1)^2 + (p2-q1)^2 + .... (pn-qn)^2))
    
    #we calculate the norm of the difference between the two n-dimensional vector p,q with numpy
    def compare(self,profile):
	self_dict=self.toDictionary()
	profile_dict=profile.toDictionary()
	self_vector=numpy.empty(shape=(0))
	profile_vector=numpy.empty(shape=(0))
	for s_d in self_dict.keys():
	    for p_d in profile_dict.keys():
		if s_d == p_d and self_dict[s_d]!="null" and profile_dict[p_d]!="null":
		    self_vector=numpy.append(self_vector,getNumerical(self_dict[s_d]))
		    profile_vector=numpy.append(profile_vector,getNumerical(profile_dict[s_d]))
		    break
	return numpy.linalg.norm(self_vector-profile_vector)

    def visualCompare(self,profile):
	ret="\t\t\t"+profile.name+"\t"+self.name+"\n"
	ret+="\t\t\t"+profile.mapping+"\t"+self.mapping+"\n"
	self_dict=self.toDictionary_name()
	profile_dict=profile.toDictionary_name()
	self_vector=numpy.empty(shape=(0))
	profile_vector=numpy.empty(shape=(0))
	for s_d in self_dict.keys():
	    for p_d in profile_dict.keys():
		if s_d == p_d and self_dict[s_d]['metric']!="null" and profile_dict[p_d]['metric']!="null":
		    ret+=str(self_dict[s_d]['name'])+"("+str(s_d)+")"+" "*(20-len(str(self_dict[s_d]['name'])))+""+str(getNumerical(profile_dict[s_d]['metric']))+"\t\t"+str(getNumerical(self_dict[p_d]['metric']))+"\n"
		    self_vector=numpy.append(self_vector,getNumerical(self_dict[s_d]['metric']))
		    profile_vector=numpy.append(profile_vector,getNumerical(profile_dict[s_d]['metric']))
		    break
	ret+="-------------\n"
	ret+="distance: "+str(numpy.linalg.norm(self_vector-profile_vector))+"\n"
	return ret 

    #returns a dictionary with ID:value
    def toDictionary(self, dictionary_dimensions={}):
	for child in self.children.keys():
	    dictionary_dimensions=self.children[child].toDictionary(dictionary_dimensions).copy()
	return dictionary_dimensions

    #returns a dictionary with name_ID:value
    def toDictionary_name(self, dictionary_dimensions={}):
	for child in self.children.keys():
	    dictionary_dimensions=self.children[child].toDictionary_name(dictionary_dimensions).copy()
	return dictionary_dimensions
	    
# class to define different dimensions, their possible values, and subdimensions
class DimensionNode():
    def __init__(self, name):
	#name was a unique id but children of aim-physical and aim-virtual have the same names so we now use id in __eq__
	self.uniqueID="" 
        self.name=name
        self.description=""
        self.notes=""
        self.metric="" 
        self.children={}
	self.metricType=[]

    def __repr__(self, level=0):
	if len(self.children) != 0:
	    ret = "\t"*level+self.name+"(ID:"+str(self.uniqueID)+")"+self.metric+"="+repr(self.metricType.index(self.metric)) #+", sanityCheck("+repr(self.calculateInternalMetrics_sanityCheck())+")"
	else:
	    ret = "\t"*level+self.name+"(ID:"+str(self.uniqueID)+")"+" "+self.metric+"="+repr(self.metricType.index(self.metric))

	if self.notes != "":
	    ret += "\t"+"("+self.notes+")"

	ret += "\n"
	
        for child in self.children.keys():
            ret += self.children[child].__repr__(level+1)
        return ret
    
    def __eq__(self, other_dimension):
	if self.uniqueID == other_dimension.uniqueID:
	    return True
	return False

    def printAttackerModel(self, level=0):
	ret = "\t"*level+self.name+" "+repr(self.metric)+"\n"
        for child in self.children.keys():
            ret += self.children[child].printAttackerModel(level+1)
        return ret

    def printAsJson(self,level=0):
	ret = "\t"*level+"\"name\": \""+self.name+"\",\n"
	ret += "\t"*level+"\"uniqueID\": "+json.dumps(self.uniqueID)+",\n"
	ret += "\t"*level+"\"metric\": \""+self.metric+"\",\n"
	ret += "\t"*level+"\"description\": \""+self.description+"\",\n"
	ret += "\t"*level+"\"notes\": \""+self.notes+"\",\n"
	ret += "\t"*level+"\"metricType\": "+json.dumps(self.metricType)+",\n"

	childNumber=0
	if len(self.children) == 0:
	    ret += "\t"*level+"\"children\": []\n"
	else:
	    ret += "\t"*level+"\"children\": [\n"
            for child in self.children.keys():
		ret+="\t"*level+" {\n"
                ret += self.children[child].printAsJson(level+1)
		if len(self.children)-1 == childNumber:
		   ret += "\t"*level+"} \n"
		else:
		   ret += "\t"*level+"},\n"

		childNumber += 1
	    ret += "\t"*level+" ]\n"

	
        return ret

    def addChild(self, obj):
        self.children[obj.name]=obj

    #by default the honest metric is set to malicious
    def setFirstMetric(self):
	if self.name == "Honesty":
	    self.metric=self.metricType[1]
	else:
	    self.metric=self.metricType[0]
	for i in self.children.values():
	    i.setFirstMetric()

    #returns the average (truncated) of values of metrics in subdimensions
    #it's only used as a sanitycheck
    #to assign the mertic use <attackerTree>.calculateInternalMetrics
    def calculateInternalMetrics_sanityCheck(self):
        ret=0
        num_elem=0
        for child in self.children.keys():
            ret+=self.children[child].metricType.index(self.children[child].metric)
            num_elem+=1
        if num_elem != 0:
            ret=(ret + num_elem // 2) //num_elem

        return ret

    #this methods assigns a value to a metric calculating the average of the value of his children
    def calculateInternalMetrics(self):
	sum_metrics_children=0
	num_elem=0
        for child in self.children.keys():
	    if self.children[child].metric != "null":
		sum_metrics_children+=self.children[child].metricType.index(self.children[child].metric)
		num_elem+=1
	if num_elem != 0:
	    self.metric=self.metricType[(sum_metrics_children + num_elem // 2) // num_elem]
	else:
	    self.metric="null"
	
    #return the value (the metric) of a dimension 
    def getValueOfDimension(self,dimension):
	ret=""
	#if dimension.lower() == self.name.lower():
	if dimension.uniqueID == self.uniqueID:
	    ret=self.metric
	else:
	    for child in self.children.keys():
		ret = self.children[child].getValueOfDimension(dimension)
		if ret != "":
		    return ret
	return ret

    def getDimensions(self,dimensions,depth):
	dimensions.append([self,depth])
        for child in self.children.keys():
            self.children[child].getDimensions(dimensions,depth+1)
	return dimensions

    def setDimension(self,mod_dimension,path):
	ret=0
	if self.name.lower() == mod_dimension.lower():
	    print path+self.name
	    if self.notes != "":
		print "current note:"+self.notes
	    else: 
		print "no notes for this dimension"
	
	    new_metric=""
	    range_metric=range(0,len(self.metricType))
	    while new_metric == "" or new_metric=="note":
		print "metric: "+repr(self.metricType)+" (you can use "+repr(range_metric)+")"+" (type \"note\" to add a note - will remove previous one)"
		new_metric=raw_input()
		if new_metric == "note":
		    print "add note:"
		    new_note=raw_input()
		    self.notes=new_note
		else:
		    try:
		        int(new_metric)
		        if int(new_metric) >= 0 and int(new_metric) <= len(self.metric)-1: 
			    self.metric=self.metricType[int(new_metric)]
			    ret=1
		        else:
			    #a wrong value has been typed
			    print "Wrong value\n"
			    new_metric=""
		    except ValueError:
		        #check if the value is correct
		        if new_metric in self.metricType:
			    self.metric=new_metric
			    ret=1
		        else:
			    #a wrong value has been typed
			    print "Wrong value\n"
			    new_metric=""
	else:
	    path=self.name+"->"
	    for child in self.children.keys():
		ret+=self.children[child].setDimension(mod_dimension,path)
	return ret

    def createInteractive(self, NewAttackerTree, path):
	#print self.name+" has "+repr(len(self.children))+" children"
	if len(self.children) == 0:
	    range_metric=range(0,len(self.metricType))
	    print "Choose value for "+path+self.name+": "+repr(self.metric)+" (you can use "+repr(range_metric)+") (type \"note\" to add notes)"
	    dimension_value=raw_input()
	    
	    if dimension_value == "note":
		print "add notes:"
		self.notes=raw_input()
		print "Choose value for "+path+self.name+": "+repr(self.metric)+" (you can use ["+repr(range_metric)+"])"
		dimension_value=raw_input()
		
	    #dimension_value is either a number or a string
	    try:
		int(dimension_value)
		if int(dimension_value) >= 0 and int(dimension_value) <= len(self.metric)-1: 
		    self.metric=self.metricType[int(dimension_value)]
	        else:
		    #a wrong value has been typed
		    print "Wrong value\n"
		    self.createInteractive(AttackerTree,path)
	    except ValueError:
	        #check if the value is correct
	        if dimension_value in self.metricType:
		    self.metric=dimension_value
	        else:
		    #a wrong value has been typed
		    print "Wrong value\n"
		    self.createInteractive(AttackerTree,path)

	else:
	    path+=self.name+"->"
	    for child in self.children.keys():
		self.children[child].createInteractive(AttackerTree,path)
	    #once calculated the value of the metrics of the leaves
	    #I calculate the average for the parent
	    self.calculateInternalMetrics()

    def createFromJson(self, jsonData):
	for child in jsonData['children']:
	    dimensionNode=DimensionNode(child['name'])
	    dimensionNode.description=child['description']
	    dimensionNode.metric=child['metric']
	    dimensionNode.metricType=listOfMetrics[listOfMetrics.index(child['metricType'])]
	    dimensionNode.notes=child['notes']
	    dimensionNode.uniqueID=child['uniqueID']
	    self.addChild(dimensionNode)
	    if len(child['children']) != 0:
		dimensionNode.createFromJson(child)

    def toDictionary(self,dictionary_dimensions={}):
	dictionary_dimensions[self.uniqueID]=self.metric
	for child in self.children.keys():
	    self.children[child].toDictionary(dictionary_dimensions)
	return dictionary_dimensions

    def toDictionary_name(self,dictionary_dimensions={}):
	dictionary_dimensions[self.uniqueID]={'name':self.name,'metric':self.metric}
	for child in self.children.keys():
	    self.children[child].toDictionary_name(dictionary_dimensions)
	return dictionary_dimensions

#other framework for attacker models 
class Framework():
    def __init__(self, name):
        self.name=name
        self.bibentry=""
	self.description=""
	self.system_modeling=""
	self.generic_specific='' #G/S
	self.time=["",""] #[presence=0/1, description]
	self.terminology=""
	self.our_terminology=""
	self.research_goal=""
	self.validation=""
	self.dimensions={} #frameworkDimension()
	self.profiles={} #frameworkProfile()
	self.actions={} #frameworkActions()
	self.test_cases={} #frameworkTestCases()
	self.filename=""

    def __repr__(self):
        ret="\nFRAMEWORK\n\tname: "+self.name+"\n"
        ret+="\tbibentry: "+self.bibentry+"\n"
	ret+="\tdescription: "+self.description+"\n"
	ret+="\tsystem modeling: "+str(self.system_modeling)+"\n"
	ret+="\tG/S: "+self.generic_specific+"\n"
	ret+="\ttime: "+str(self.time[0])
	ret+="\t("+self.time[1]+")\n"
	ret+="\tterminology: "+self.terminology+"\n"
	ret+="\tour terminology: "+self.our_terminology+"\n"
	ret+="\tresearch goal: "+self.research_goal+"\n"
	ret+="\tvalidation: "+str(self.validation)+"\n"
	ret+="\n\t##########\n"
	ret+="\tDIMENSIONS:\n"
	ret+="\t##########\n"
	for dimension in self.dimensions.keys():
	    ret+=self.dimensions[dimension].__repr__()+"\n"

	ret+="\n\t##########\n"
	ret+="\tPROFILES:\n"
	ret+="\t##########\n"
	for profile in self.profiles.keys():
	    ret+=self.profiles[profile].__repr__()+"\n"

	ret+="\n\t##########\n"
	ret+="\tACTIONS:\n"
	ret+="\t##########\n"
	for action in self.actions.keys():
	    ret+=self.actions[action].__repr__()+"\n"

	ret+="\n\t##########\n"
	ret+="\tTEST CASES:\n"
	ret+="\t##########\n"
	for test_case in self.test_cases.keys():
	    ret+=self.test_cases[test_case].__repr__()+"\n"
	return ret

    def createInteractive(self):
	print "bibentry:"
	temp_bibentry=raw_input()
    
	print "description:"
	temp_description=raw_input()

	print "system modeling (true/false):"
	temp_system_modeling=raw_input()

	print "generic/specific (G/S):"
	temp_generic_specific=raw_input()

	print "terminology used (At/I/Ad/T/S/Atk + [M/P]):"
	temp_terminology=raw_input()

	print "our terminology (At/I/Ad/T/S/Atk + [M/P]):"
	temp_our_terminology=raw_input()

	print "research goal (Risk Analysis, Threat Assessment, Security Analysis, Testing, Intrusion Detection, Survey, Quantitative Evaluation, Definition, Overview):"
	temp_research_goal=raw_input()

	print "validation (true/false):"
	temp_validation=raw_input()

	print "time: (true/false)"
	temp_time_considered=raw_input()

	print "time description:"
	temp_time_description=raw_input()

        self.bibentry=temp_bibentry
	self.description=temp_description
	self.system_modeling=temp_system_modeling
	self.generic_specific=temp_generic_specific
	self.time[0]=temp_time_considered
	self.time[1]=temp_time_description
	self.terminology=temp_terminology
	self.our_terminology=temp_our_terminology
	self.research_goal=temp_research_goal
	self.validation=temp_validation

	stop=""
	print "\nDIMENSIONS"
	while stop != "stop":
	    print "\nname: (stop to stop)"
	    name=raw_input()
	    if name == "stop":
		stop="stop"
	    else:
		fd=frameworkDimension(name)
		fd.createInteractive()
		self.dimensions[fd.name]=fd

	stop=""
	print "\nPROFILES"
	while stop != "stop":
	    print "\nname: (stop to stop)"
	    name=raw_input()
	    if name == "stop":
		stop="stop"
	    else:
		fp=frameworkProfile(name)
		fp.createInteractive()
		self.profiles[fp.name]=fp

	stop=""
	print "\nACTIONS"
	while stop != "stop":
	    print "\nname: (stop to stop)"
	    name=raw_input()
	    if name == "stop":
		stop="stop"
	    else:
		fa=frameworkAction(name)
		fa.createInteractive()
		self.actions[fa.name]=fa
	
	stop=""
	print "\nTEST_CASES"
	while stop != "stop":
	    print "\nname: (stop to stop)"
	    name=raw_input()
	    if name == "stop":
		stop="stop"
	    else:
		ft=frameworkTestCase(name)
		ft.createInteractive()
		self.test_cases[ft.name]=ft
	
    def saveTofile(self, filetype):
	self.filename=LITERATURE_DIR_PATH+LITERATURE_DIR+"/"+self.name+"."+filetype
	while os.path.isfile(self.filename) == True:
	    print "file "+self.filename+" already exists, please provide another name (without extension)"
	    filenameTemp=raw_input()
	    self.filename=LITERATURE_DIR_PATH+LITERATURE_DIR+"/"+filenameTemp+"."+filetype
	f=open(self.filename,'w')
	if filetype == "json":
	    f.write(self.printAsJson())
	else:
	    print "filetype: "+filetype+" not supported"
	f.close()

    def printAsJson(self):
	ret = "{"+"\t\n\t\"name\": \""+self.name+"\",\n"
	ret += "\t\"bibentry\": \""+self.bibentry+"\",\n"
	ret += "\t\"description\": "+json.dumps(self.description)+",\n"
	ret += "\t\"system_modeling\": \""+self.system_modeling+"\",\n"
	ret += "\t\"generic_specific\": \""+self.generic_specific+"\",\n"
	ret += "\t\"terminology\": \""+self.terminology+"\",\n"
	ret += "\t\"our_terminology\": \""+self.our_terminology+"\",\n"
	ret += "\t\"research_goal\": \""+self.research_goal+"\",\n"
	ret += "\t\"validation\": "+json.dumps(self.validation)+",\n"
	ret += "\t\"time\": {\n"
	ret += "\t\t\"considered\": "+json.dumps(self.time[0])+",\n"
	ret += "\t\t\"description\": \""+self.time[1]+"\"\n"
	ret += "\t\t},\n"
	
	ret += "\t\"dimensions\":\n"
	ret += "\t[\n"
	childNumber=0
	for dimension in self.dimensions.keys():
	    ret += "\t\t{\n"
	    ret += "\t\t\"name\": \""+self.dimensions[dimension].name+"\",\n"
	    ret += "\t\t\"description\": \""+self.dimensions[dimension].description+"\",\n"
	    ret += "\t\t\"mapping\": [\n"
	    childMapping_num=0
	    for mapping_item in self.dimensions[dimension].mapping:
		ret+="\t\t\t{\"dimension\": \""+str(mapping_item)
		if childMapping_num == len(self.dimensions[dimension].mapping)-1:
		    ret+="\"}\n"
		else:
		    ret+="\"},\n"
		childMapping_num+=1

	    ret += "\t\t]\n"

	    if len(self.dimensions)-1 == childNumber:
		ret += "\t\t}\n"
	    else: 
		ret += "\t\t},\n"
	    childNumber += 1
	ret += "\t],\n"

	ret += "\t\"profiles\":\n"
	ret += "\t[\n"
	childNumber=0
	for profile in self.profiles.keys():
	    ret += "\t\t{\n"
	    ret += "\t\t\"name\": \""+self.profiles[profile].name+"\",\n"
	    ret += "\t\t\"description\": \""+self.profiles[profile].description+"\",\n"
	    ret += "\t\t\"mapping\": \""+self.profiles[profile].mapping+"\"\n"
	    if len(self.profiles)-1 == childNumber:
		ret += "\t\t}\n"
	    else: 
		ret += "\t\t},\n"
	    childNumber += 1
	ret += "\t],\n"

	ret += "\t\"actions\":\n"
	ret += "\t[\n"
	childNumber=0
	for action in self.actions.keys():
	    ret += "\t\t{\n"
	    ret += "\t\t\"name\": \""+self.actions[action].name+"\",\n"
	    ret += "\t\t\"description\": \""+self.actions[action].description+"\"\n"
	    if len(self.actions)-1 == childNumber:
		ret += "\t\t}\n"
	    else: 
		ret += "\t\t},\n"
	    childNumber += 1
	ret += "\t],\n"

	ret += "\t\"test_cases\":\n"
	ret += "\t[\n"
	childNumber=0
	for test_case in self.test_cases.keys():
	    ret += "\t\t{\n"
	    ret += "\t\t\"name\": \""+self.test_cases[test_case].name+"\",\n"
	    ret += "\t\t\"description\": \""+self.test_cases[test_case].description+"\"\n"
	    if len(self.test_cases)-1 == childNumber:
		ret += "\t\t}\n"
	    else: 
		ret += "\t\t},\n"
	    childNumber += 1
	ret += "\t]\n"

	ret+="\n}\n"
	return ret

    #filename is defined in menu_loadFramework
    def createFromJson(self,json):
	self.name=json['name']
	self.description=json['description']
	self.bibentry=json['bibentry']
	self.system_modeling=json['system_modeling']
	self.generic_specific=json['generic_specific'] 
	self.terminology=json['terminology']
	self.our_terminology=json['our_terminology']
	self.research_goal=json['research_goal']
	self.validation=json['validation']
	self.time[0]=json['time']['considered']
	self.time[1]=json['time']['description']
	for dimension in json['dimensions']:
	    fd=frameworkDimension(dimension['name'])
	    self.dimensions[dimension['name']]=fd.createFromJson(dimension)

	for profile in json['profiles']:
	    fd=frameworkProfile(profile['name'])
	    self.profiles[profile['name']]=fd.createFromJson(profile)

	for action in json['actions']:
	    fd=frameworkAction(action['name'])
	    self.actions[action['name']]=fd.createFromJson(action)

	for test_case in json['test_cases']:
	    fd=frameworkTestCase(test_case['name'])
	    self.test_cases[test_case['name']]=fd.createFromJson(test_case)


class frameworkDimension():
    def __init__(self, name):
	self.name=name
	self.description=""
	self.mapping=[]

    def __repr__(self):
	ret="\tname: "+self.name+"\n"
	ret+="\tdescription: "+self.description+"\n"
	ret+="\tmapping: \n"
	for mapping_item in self.mapping:
	    ret+="\t\t"+str(mapping_item)+"\n"
	return ret

    def createInteractive(self):
	if self.name == "":
	    print "Dimension name:"
	    tmp_name=raw_input()
	    self.name=tmp_name

	print "Dimension description:"
	tmp_description=raw_input()

	stop=0
	tmp_mapping=[]
	while stop == 0:
	    print "Dimension mapping: (stop to stop)"
	    tmp_mapping_item=raw_input()
	    if tmp_mapping_item == "stop":
		stop=1
	    else:
		tmp_mapping.append(tmp_mapping_item)
    	
	self.description=tmp_description
	self.mapping=tmp_mapping
	return self

    def createFromJson(self,json):
	if self.name == "":
	    self.name=json['name']
	if 'description' in json:
	    self.description=json['description']
	if 'mapping' in json:
	    for mapping_item in json['mapping']:
		self.mapping.append(mapping_item['dimension'])
	return self

class frameworkProfile():
    def __init__(self, name):
	self.name=name
	self.description=""
	self.mapping=""

    def __repr__(self):
	ret="\tname: "+self.name+"\n"
	ret+="\tdescription: "+self.description+"\n"
	ret+="\tmapping: "+self.mapping+"\n"
	return ret

    def createInteractive(self):
	if self.name == "":
	    print "Profile name:"
	    tmp_name=raw_input()
	    self.name=tmp_name

	print "Profile description:"
	tmp_description=raw_input()

	print "Profile mapping:"
	tmp_mapping=raw_input()
    	
	self.description=tmp_description
	self.mapping=tmp_mapping
	return self

    def createFromJson(self,json):
	if self.name == "":
	    self.name=json['name']
	if 'description' in json:
	    self.description=json['description']
	if 'mapping' in json:
	    self.mapping=json['mapping']
	return self

class frameworkAction():
    def __init__(self, name):
	self.name=name
	self.description=""

    def __repr__(self):
	ret="\tname: "+self.name+"\n"
	ret+="\tdescription: "+self.description+"\n"
	return ret

    def createInteractive(self):
	if self.name == "":
	    print "Action name:"
	    tmp_name=raw_input()
	    self.name=tmp_name

	print "Action description:"
	tmp_description=raw_input()
	self.description=tmp_description
	return self

    def createFromJson(self,json):
	if self.name == "":
	    self.name=json['name']
	if 'description' in json:
	    self.description=json['description']
	return self

class frameworkTestCase():
    def __init__(self, name):
	self.name=name
	self.description=""

    def __repr__(self):
	ret="\tname: "+self.name+"\n"
	ret+="\tdescription: "+self.description+"\n"
	return ret

    def createInteractive(self):
	if self.name == "":
	    print "TestCase name:"
	    tmp_name=raw_input()
	    self.name=tmp_name

	print "TestCase description:"
	tmp_description=raw_input()
	self.description=tmp_description
	return self

    def createFromJson(self,json):
	if self.name == "":
	    self.name=json['name']
	if 'description' in json:
	    self.description=json['description']
	return self

#print latex table of all profiles
#filtrate: 
# - all: print all profiles (our and theirs) DEFAULT
# - our: print our profiles
# - literature: print only the profiles we have found in the literature
def printProfilesTable(attackerModels,caption,label,filtrate="all"):
    #attackerProfiles_our is a list with our profiles define at the end of the file
    attackerModels_temp=[]
    if filtrate == "our":
	attackerModels_temp=attackerModels_our
	description="{\\centering \\textbf{B}=BasicUser, \\textbf{C}=Cybercriminal, \\textbf{H}=Hacktivist, \\textbf{I}=Insider, \\textbf{N}=NationState, \\textbf{T}=Terrorist.A metric on each dimensions is expressed on the (strict) partially ordered set $[\\Twdot<\\Thdot<\\Tdot]$}\n"
    elif filtrate == "literature":
	attackerModels_temp=attackerModels_other
	description="{\\centering A metric on each dimensions is expressed on the (strict) partially ordered set $[\\Twdot<\\Thdot<\\Tdot]$}\n"

    else:
	attackerModels_temp=attackerModels 
	description="{\\centering \\textbf{B}=BasicUser, \\textbf{C}=Cybercriminal, \\textbf{H}=Hacktivist, \\textbf{I}=Insider, \\textbf{N}=NationState, \\textbf{T}=Terrorist.A metric on each dimensions is expressed on the (strict) partially ordered set $[\\Twdot<\\Thdot<\\Tdot]$}\n"

    ret="\\begin{table*}\n\\centering\n\\caption{"+caption+"\\label{"+label+"}}\n\\begin{tabular}\n"

    ret+="{l"+"c"*len(attackerModels_temp)+"}\n\\toprule \n Dimensions&\n"
    
    for atkmod in attackerModels_temp:
	if attackerModels_temp.index(atkmod)+1 == len(attackerModels_temp):
	    if filtrate == "our":
		ret+="\\rot{\\textbf{"+re.escape(atkmod.name)[0]+"}}\\\\\n"
	    else:
		ret+="\\rot{"+re.escape(atkmod.name)+"}\\\\\n"
	else:
	    if filtrate == "our":
		ret+="\\rot{\\textbf{"+re.escape(atkmod.name)[0]+"}}&\n"
	    else:
		ret+="\\rot{"+re.escape(atkmod.name)+"}&\n"

    ret+="\\midrule\n"

    #assume every attacker has the same dimensions
    dimensions=attackerModels_temp[0].getDimensions()

    for dimension in dimensions:
	ret+="~~~"*dimension[1]+dimension[0].name+" & "
	for atkmod in attackerModels_temp:
	    if attackerModels_temp.index(atkmod)+1 != len(attackerModels_temp):
		ret+=mapToCircles(atkmod.getValueOfDimension(dimension[0]))+" & "
	    else:
		ret+=mapToCircles(atkmod.getValueOfDimension(dimension[0]))+"\\\\"
	ret+="\n"

    ret+="\\bottomrule\n\\end{tabular}\n"
    ret+="\n"+description
    ret+="\\end{table*}"
    return ret

def printProfilesMappingTable(attackerModels,caption,label):
    ret="\\begin{table*}\n\\centering\n\\caption{"+caption+"\\label{"+label+"}}\n\\begin{tabular}\n"
    ret+="{l"+"l"*len(attackerModels_our)+"}\n\\toprule \nProfile&\n"
    
    near=1
    for atkmod in attackerModels_our:
	if attackerModels_our.index(atkmod)+1 == len(attackerModels_our):
	    ret+="\#"+str(near)+"\\\\\n"
	else:
	    ret+="\#"+str(near)+"&\n"
	near+=1

    ret+="\\midrule\n"
    
    #dictionary (name:expectedResult)
    name_expected={}
    for ette in attackerModels_other:
	name_expected[ette.name.lower().replace(" ","")]=ette.mapping.lower()
    	
    comparison=comp()
    tot=[0,0,0,0,0,0]
    for i in sorted(comparison.keys()):
	profile=i
	distance=-1
	our_profiles=""
	nearest=""
	profile_list=[]
	for j in comparison[i].keys():
	    our_profiles+=j+" "+str(comparison[i][j])+"\n"
	    profile_list.append({'name':j,'distance':comparison[i][j]})
	    if distance == -1:
		nearest=j
		distance=comparison[i][j]
	    elif distance > comparison[i][j]: 
		nearest=j
		distance=comparison[i][j]
	profile_list.sort(key=lambda profile_list: profile_list['distance'])
	ordered_profiles=""

	#bring the expected result first when previous have the same value
	first_elem=profile_list[0]
	index=0
	if first_elem['name'].lower()!=name_expected[profile.lower().replace(" ","")]:
	    for a in profile_list:
		if a['name'].lower()==name_expected[profile.lower().replace(" ","")]:
		    #a is the expected
		    if str(a['distance'])[0:4] == str(first_elem['distance'])[0:4]:
			profile_list[index],profile_list[0]=profile_list[0],profile_list[index]
			break
		    else:
			index2=0
			for b in profile_list: 
			    if str(a['distance'])[0:4] == str(b['distance'])[0:4] and index2 < index:
				profile_list[index],profile_list[index2]=profile_list[index2],profile_list[index]
				break
			    index2+=1
		index+=1
	    
	#print the table
	pos=0	
	for a in profile_list:
	    add_expected=False
	    if name_expected[profile.lower().replace(" ","")] == a['name'].lower():
		add_expected=True
		tot[pos]+=1
	    if pos == len(profile_list)-1:
		if add_expected:
		    ordered_profiles+="\\underline{\\textbf{"+a['name'][0]+"}~("+str(a['distance'])[0:4]+")}"
		else:
		    ordered_profiles+="\\textbf{"+a['name'][0]+"}~("+str(a['distance'])[0:4]+")"
	    else:
		if add_expected:
		    ordered_profiles+="\\underline{\\textbf{"+a['name'][0]+"}~("+str(a['distance'])[0:4]+")}&"
		else:
		    ordered_profiles+="\\textbf{"+a['name'][0]+"}~("+str(a['distance'])[0:4]+")&"
	    pos+=1
	    
	ret+=re.escape(profile)+"&"+ordered_profiles+"\\\\\n"
    
    ret+="\#Expected "
    for t in tot:
	ret+=" &"+str(t)
    ret+="\\\\\n"
    ret+="\\bottomrule\n\\end{tabular}\n"
    ret+="\n{\\centering B=BasicUser, C=Cybercriminal, H=Hacktivist, I=Insider, N=NationState, T=Terrorist, (Float)=Euclidean distance, \underline{X(x.x)}=Expected mapping}\n"
    ret+="\\end{table*}"
    return ret

#print latex table of the taxonomy
def printTaxonomyTable(frameworks,caption,label):
    ret="\\begin{table*}\n\\centering\n\\caption{"+caption+"\\label{"+label+"}}\n\\begin{tabular}"

    ret+="{l"+"c"*11+"lll}\n\\toprule\n Publication&\n"
    ret+="&\n"
    ret+="\\rot{\\#Profiles}&\n"
    ret+="\\rot{\\#Dimensions}&\n"
    ret+="\\rot{\\#Actions}&\n"
    ret+="\\rot{System Modeling}&\n"
    ret+="\\rot{Validation}&\n"
    ret+="\\rot{Generic/Specific}&\n"
    ret+="\\rot{\\#Test Cases}&\n"
    ret+="\\rot{Time}&\n"
    ret+="\\rot{Terminology used}&\n"
    ret+="\\rot{Our terminology}&\n"
    ret+="Research Goal\\\\\n"
    ret+="\\midrule\n"

    for framework in frameworks:
	#name
	ret+=framework.name+" "
	#bibentry
	ret+="~\\cite{"+framework.bibentry+"} &"
	#nice empty space
	ret+=" & "
	#number of profiles 
	ret+=str(len(framework.profiles))+" & "
	#number of dimensions
	ret+=str(len(framework.dimensions))+" & "
	#number of actions
	ret+=str(len(framework.actions))+" & "
	#system modeling (true/false)
	ret+=mapToCircles(framework.system_modeling)+" & "
	#validation (true/false)
	ret+=mapToCircles(framework.validation)+" & "
	#generic/specific
	ret+=framework.generic_specific.upper()+" & "
	#number of test cases
	ret+=str(len(framework.test_cases))+" & "
	#time
	ret+="&"+mapToCircles(framework.time[0])+" & "
	#terminology used by authors
	ret+=framework.terminology+" & "
	#our terminology
	ret+=framework.our_terminology+" & "
	#research goal
	ret+=framework.research_goal.title()+" \\\\\n"
	
	
    ret+="\\bottomrule\n\\end{tabular}\n"
    ret+="\n{\\centering $\\Tdot=$ argument discussed, $\\Thdot=$ briefly discussed or mentioned, $\\Twdot=$ not discussed, At=Attacker, I=Intruder, Ad=Adversary, T=Threat, S=System, Atk=Attack, M=Model, P=Profile}\n"
    ret+="\\end{table*}"
    return ret

def printDimensionsReviewTable(attackerModels,caption,label):
    ret="\\begin{table*}\n\\centering\n\\caption{"+caption+"\\label{"+label+"}}\n\\begin{tabular}\n"

    ret+="{l"+"c"*len(attackerModels)+"}\n\\toprule \n Dimensions&\n"
    
    for atkmod in attackerModels:
	if attackerModels.index(atkmod)+1 == len(attackerModels):
	    ret+="\\rot{"+re.escape(atkmod.name)+" ~\\cite{"+atkmod.bibentry+"}}\\\\\n"
	else:
	    ret+="\\rot{"+re.escape(atkmod.name)+" ~\\cite{"+atkmod.bibentry+"}}&\n"

    ret+="\\midrule\n"

    dimensionsFromReview=[]
    checkmapping=0
    for framework in frameworks:
	for dimension in framework.dimensions.keys():
	    for m in framework.dimensions[dimension].mapping:
		checkmapping+=1
		if not(str(m).lower() in dimensionsFromReview):
		    dimensionsFromReview.append(str(m).lower())
	    if checkmapping == 0 and not(str(framework.dimensions[dimension].mapping).lower() in dimensionsFromReview):
		    dimensionsFromReview.append(str(framework.dimensions[dimension].name).lower())
	    checkmapping=0
		

    for dim in dimensionsFromReview:
	ret+=dim.title()+" & "
	last=0
	for framework in frameworks:
	    found=False 
	    for dimension in framework.dimensions.keys():
		checkmapping=0
		for m in framework.dimensions[dimension].mapping:
		    checkmapping+=1
		    if str(m).lower() == dim.lower():
		        ret+="\\Tdot " 
		        found=True
		        break
		if found:
		    break
		if not(found) and framework.dimensions[dimension].name.lower() == dim.lower() and checkmapping == 0:
		    ret+="\\Tdot " 
		    found=True
		    break

	    if not(found) and len(frameworks)-1 != last:
		ret+=" & "
	    elif not(found) and len(frameworks)-1 == last:
		ret+="\\\\\n"
	    elif found and len(frameworks)-1 == last:
		ret+="\\\\\n"
	    elif found and len(frameworks)-1 != last:
		ret+=" & "

	    last+=1

    ret+="\\bottomrule\n\\end{tabular}\n\\end{table*}"
    return ret

#map metric to human-understandable latex symbol
#each metrics now is a partial order with 3 symbols [1<2<3]
#and they are mapped to: 
#% circles
#\newcommand{\Tdot}{$\CIRCLE$}
#\newcommand{\Thdot}{$\LEFTcircle$}
#\newcommand{\Twdot}{$\Circle$}
#it also maps true/false into empty/full circles
def mapToCircles(metricValue):
    ret=""
    if metricValue == "true":
	ret="\\Tdot"
    elif metricValue == "false":
	ret="\\Twdot"
    else:
        for metric in listOfMetrics:
	    if metricValue in metric:
		ret=metric.index(metricValue)
		if len(metric) == 3 and ret == 2:
		    ret+=1

        if ret == 0:
	    ret=""
        elif ret == 1:
	    ret="$\\Twdot$"
        elif ret == 2:
	    ret="$\\Thdot$"
        elif ret == 3:
	    ret="$\\Tdot$"

    return ret

#returns the numerical representation of a metric
def getNumerical(metricValue):
    ret=0
    for metric in listOfMetrics:
	if metricValue in metric:
	    ret=metric.index(metricValue)
	    break

    return ret

def createNewAttackerModel():
    print "Name:"
    na_name=raw_input()
    na=AttackerTree(na_name)
    print "Brief description:" 
    na.description=raw_input()
    print "BibEntry:" 
    na.bibentry=raw_input()
    print "Mapping:" 
    na.mapping=raw_input()
    na.createInteractive(attackerModel)
    print na
    return na 


#compares a profile with self
#by calculating the euclidean distance between the two vectors representing the two profiles
#the dimensionality is equal to the number of dimensions
#the formula for Euclidean distance between two points p,q in a n-dimensional space is the following
#sqrt(sum((p1-q1)^2 + (p2-q1)^2 + .... (pn-qn)^2))
def comp():
    #the following is the output
    #comparison_list=['attackerProfileLiterature',['attackerProfile_our',%distance]]
    comparison={}
    comparison_all={}
    best_fit_name=""
    best_fit_num=0
    
    for attackerModel_other in attackerModels_other:
	for attackerModel_our in attackerModels_our:
	    comparison[attackerModel_our.name]=attackerModel_our.compare(attackerModel_other)
	comparison_all[attackerModel_other.name]=comparison.copy()
    
    return comparison_all

# the order of the attributes follows the uniqueID
def generate_weka_input():
    print "training set (our profiles), literature profiles or literature profiles labeled? (TS/LP/LPL)"
    tp_lp=raw_input()
    if tp_lp.lower() == "ts":
	profiles=attackerModels_our
    else:
	profiles=attackerModels_other
    
    ret="\n\n\n@relation attackerProfile\n\n"
    temp_dimensions={}
	
    dimensions=attackerModel.getDimensions()
    for d in dimensions:
	temp_dimensions[d[0].uniqueID]=d[0].name

    if tp_lp.lower() =="ts" or tp_lp.lower() == "lpl":
	ret+="@attribute type {basicuser, cybercriminal, hacktivist, insider, nationstate, terrorist}\n"

    for t_d in sorted(temp_dimensions.keys(), key=int):
	ret+="@attribute "+temp_dimensions[t_d].replace(" ","")+"_"+str(t_d)+" {1, 2, 3}\n"
    
    ret+="\n@data\n\n"

    for profile in profiles:
	if tp_lp.lower() == "ts":
	    ret+=profile.name.lower()+","
	elif tp_lp.lower() == "lpl":
	    ret+=profile.mapping.lower().replace(" ","")+","
	    
    	profile_dictionary=profile.toDictionary()
	i=0
	for k in sorted(profile_dictionary.keys(), key=int):
	    if profile_dictionary[k] != "null":
		ret+=str(getNumerical(profile_dictionary[k]))
	    else:
		ret+="?"
	    
	    if i == len(profile_dictionary)-1:
		ret+="\n"
	    else:
		ret+=","
	    i+=1
    return ret

## MENU
def getMenu():
    ret=0
    #i=0
    menu="ATTACKER PROFILER EXAMINER\n1.Attacker Model (Dimensions & Metrics)\n2.Load Attacker Models and Frameworks\n3.Existing Attacker Models ("+str(len(attackerModels))+")\n"
    #the following code shows the name of all attacker models in the menu but the list is now too long
    #for attacker in attackerModels:
    #    menu+="   3."+repr(i)+" "+attacker.name+"\n"
    #    i+=1
    menu+="4.LaTeX tables\n5.New attacker model\n6.Modify attacker model\n7.Create New Framework\n8.Existing Frameworks ("+str(len(frameworks))+")\n"
    #the following code shows the name of all frameworks in the menu but the list is now too long
    #i=0
    #for framework in frameworks:
    #    menu+="   8."+repr(i)+" "+framework.name+"\n"
    #    i+=1
    menu+="9.Clustering\n10.WEKA input\n11.Diff profiles\n12.Quit"
    print "\n"+menu
    opt=raw_input()
    if opt == '1':
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	print attackerModel
    elif opt == '2': 
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_loadAttackerModels()
	menu_loadFrameworks()
    elif opt == '3': 
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_existingAttackerModels()
    #we should remove this check and directly check the substring
    elif len(opt) >= 3:
	attackerModel_number=opt[2:]
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	#framework or attacker models
	if opt[0] == "3":	
	    print attackerModels[int(attackerModel_number)]
	elif opt[0] == "8":
	    print frameworks[int(attackerModel_number)]
    
    elif opt == '4': 
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_latexTables()	
    elif opt == '5':
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_createNewAttackerModel()
	menu_loadAttackerModels()
    elif opt == '6':
	menu_modifyAttackerModel()
    elif opt == '7':
	menu_createNewFramework()
	menu_loadFrameworks()
    elif opt == '8': 
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_existingFrameworks()
    elif opt == '9':
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_comp()
    elif opt == '10':
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	print generate_weka_input() 
    elif opt == '11':
	sys.stdout.write(os.popen('clear').read()) # clear screen 
	menu_diff()
    elif opt == '12':
	print "bye"
	ret=-1
    return ret


def menu_diff():
    menu_existingAttackerModels()
    print "\nProfile 1:"
    p1=raw_input()
    print "Profile 2:"
    p2=raw_input()
    profile1=attackerModels[int(p1[2:])]
    profile2=attackerModels[int(p2[2:])]
    print profile1.visualCompare(profile2)
    
def menu_comp():
    comparison_all=comp()
    for i in comparison_all.keys():
	profile=i
	distance=-1
	our_profiles=""
	nearest=""
	for j in comparison_all[i].keys():
	    our_profiles+=j+" "+str(comparison_all[i][j])+"\n"
	    if distance == -1:
		nearest=j
		distance=comparison_all[i][j]
	    elif distance > comparison_all[i][j]: 
		nearest=j
		distance=comparison_all[i][j]
	print profile+" -> "+nearest+" ("+str(distance)+") \n"+our_profiles+"\n\n"

def menu_latexTables():
	print "\nTABLES:\n 4.1 All profiles\n 4.2 Our profiles\n 4.3 Profiles reviewed\n 4.4 Profiles Mapping\n 4.5 Taxonomy\n 4.6 Dimensions Related Work\n"
	opt=raw_input()
	if len(attackerModels) != 0:
	    if opt[2] == "1":
		print printProfilesTable(attackerModels,"Attacker profiles","tab:comparison_all")
	    elif opt[2] == "2":
		print printProfilesTable(attackerModels,"Categorization of attacker profiles archetypes","tab:comparison_our",filtrate="our")
	    elif opt[2] == "3":
		print printProfilesTable(attackerModels,"Categorization of attacker profiles found in the related work","tab:comparison_review", filtrate="literature")
	    elif opt[2] == "4":
		print printProfilesMappingTable(attackerModels,"Mapping of attacker profiles from related work to our proposed six profiles","tab:mapping")
	    elif opt[2] == "5":
		print printTaxonomyTable(frameworks,"Summary of taxonomy of related work on attacker models and profiles for CPS","table:testtable")
	    elif opt[2] == "6":
		print printDimensionsReviewTable(frameworks,"Dimensions proposed in the related work","table:dimensions_review")
	else:
	    print "No attacker model found. Create or load one first"

def menu_loadAttackerModels():
    attackerModelsInDir=glob.glob(ATTACKER_PROFILES_DIR_PATH+ATTACKER_PROFILES_DIR+"/*.json")
    for atkmodel in attackerModelsInDir:
        fileAM=open(atkmodel)
        amdata = json.load(fileAM)
        alreadyPresent=False
        for atkmode in attackerModels:
	    if atkmode.name == amdata['name']:
		alreadyPresent=True
		break
        if alreadyPresent == False:
	    am=AttackerTree(amdata['name'])
	    am.description=amdata['description']
	    am.bibentry=amdata['bibentry']
	    am.mapping=amdata['mapping']
	    am.filename=str(atkmodel)
	    am.createFromJson(amdata)
	    attackerModels.append(am)	

    attackerModels.sort(key=lambda attackerModel: attackerModel.name)

def menu_loadFrameworks():
    frameworksInDir=glob.glob(LITERATURE_DIR_PATH+LITERATURE_DIR+"/*.json")
    for framework in frameworksInDir:
        fileFM=open(framework)
        fmdata = json.load(fileFM)
        alreadyPresent=False
        for frameworkObj in frameworks:
	    if frameworkObj.name == fmdata['name']:
		alreadyPresent=True
		break
        if alreadyPresent == False:
	    fm=Framework(fmdata['name'])
	    fm.filename=str(framework)
	    fm.createFromJson(fmdata)
	    frameworks.append(fm)	

    frameworks.sort(key=lambda framework: framework.name)

def menu_existingAttackerModels():
    i=0
    if len(attackerModels) == 0:
        print "the list is currently empty, load or create attacker models first"
       #print glob.glob("./attackerModels/*.json")
    
    for attacker in attackerModels:
        print "   3."+repr(i)+" "+attacker.name+ " (map:"+attacker.mapping+")"
        i+=1
    i=0

def menu_existingFrameworks():
    i=0
    if len(frameworks) == 0:
        print "the list is currently empty, load or create frameworks first"
       #print glob.glob("./attackerModels/*.json")
    
    for framework in frameworks:
        print "   8."+repr(i)+" "+framework.name
        i+=1
    i=0

def menu_createNewAttackerModel():
	na=createNewAttackerModel()
	print "Save attacker model as Json? (Y/n)"
	na_save=raw_input()

	while na_save != "" and na_save.lower() != "n" and na_save.lower() != "y":
	    print "incorrect input provided"
	    print "Save attacker model as Json? (Y/n)"
	    na_save=raw_input()
	    
	if na_save == "" or na_save.lower()=="y":
	    na.saveTofile("json")
	    print na.name+" SAVED\n"
	else:
	    print na.name+" NOT SAVED\n"

def menu_modifyAttackerModel():
    num_check=0
    while num_check == 0:
	print "modify attacker model:"
        num_attackerTemp=raw_input()
	try:
	    num_attacker=int(num_attackerTemp.partition(".")[2])
	    pre=int(num_attackerTemp.partition(".")[0])
	    if pre == 3 and num_attacker >= 0 and num_attacker <= len(attackerModels)-1: 
		num_check=1
	    else:
	        print "Wrong value\n"
	except ValueError:
	    print "Wrong value\n"
	
    stop=0
    while stop == 0:
	print "dimension: (enter to print the attacker) (stop to stop)"
	mod_dim=raw_input()
	if mod_dim == "stop":
	    stop=1
	    break

	while mod_dim == "":
	    print repr(attackerModels[num_attacker])
	    print "dimension: (enter to print the attacker) (stop to stop)"
	    mod_dim=raw_input()
	    if mod_dim == "stop":
		stop=1
		break

        ret=attackerModels[num_attacker].setDimension(mod_dim)
	if ret == 1:
	    os.remove(attackerModels[num_attacker].filename)
	    attackerModels[num_attacker].saveTofile("json")
        else:
	    print "Error: attacker profile not modified"
    
    print repr(attackerModels[num_attacker])
    
    	
def menu_createNewFramework():
	print "Framework name:"
	nf_name=raw_input()
	nf=Framework(nf_name)
	nf.createInteractive()

	print "Save framework as Json? (Y/n)"
	nf_save=raw_input()

	while nf_save != "" and nf_save.lower() != "n" and nf_save.lower() != "y":
	    print "incorrect input provided"
	    print "Save attacker model as Json? (Y/n)"
	    nf_save=raw_input()
	    
	if nf_save == "" or nf_save.lower()=="y":
	    nf.saveTofile("json")
	    print nf.name+" SAVED\n"
	else:
	    print nf.name+" NOT SAVED\n"

#################
# METRICS 
# [1<2<3]
#################
m_level=["null","low","medium","high"]
m_expertise=["null","basic","intermediate","advanced"]
m_visibility=["null","visible","stealthy","invisible"]
m_distance=["null","far","near","physical-access"]
m_attackBox=["null","black-box","gray-box","white-box"]
m_aim=["null","none","medium","high"]
m_honesty=["null","benign","malicious"]
m_periodicity=["null","once","anytime","continuous"]
m_determination=["null","first-attempt","several-attempts","relentless"]
m_effort=["null","low","medium","high"]
m_psychology=["null","weak","average","strong"]
m_access=["null","user","supervisor","admin"]
m_strategy=["null","random","brute-force","structured"]

#if you add a new metric add it to the following list
listOfMetrics=[m_level,m_expertise,m_visibility,m_distance,m_attackBox,m_aim,m_honesty,m_periodicity,m_determination,m_effort,m_psychology,m_access,m_strategy]


#################
# DIMENSIONS 
#################
knowledge=DimensionNode("Knowledge")
knowledge.description="represents the understanding of the system under attack and the expertise of the attacker"
knowledge.metric=m_level
knowledge.metricType=m_level
knowledge.uniqueID=1

resources=DimensionNode("Resources")
resources.description="Represents the resources available to the attacker. It can be used to limit the practical capabilities of the attacker"
resources.metric=m_level
resources.metricType=m_level
resources.uniqueID=2

psychology=DimensionNode("Psychology")
psychology.description="Represents a set of aspects which are not directly related to the knowledge or resources of the attacker. These aspects are related to the motivations or behavioral aspects of the attacker"
psychology.metric=m_psychology
psychology.metricType=m_psychology
psychology.uniqueID=3

#################
# 1*SUB DIMENSIONS 
#################

# KNOWLEDGE
offensive=DimensionNode("Offensive")
offensive.description="Determines the expertise of the attacker with regard to the attacks known, e.g., attack methodologies, attack patterns"
offensive.metric=m_expertise
offensive.metricType=m_expertise
offensive.uniqueID=4
knowledge.addChild(offensive)

systemKnowledge=DimensionNode("System")
systemKnowledge.description="expresses the knowledge of the system under attack/analysis, for example, the set of components of a CPS or entities in a security protocol"
systemKnowledge.metric=m_expertise
systemKnowledge.metricType=m_expertise
systemKnowledge.uniqueID=5
knowledge.addChild(systemKnowledge)

# PSYCHOLOGY 
honesty=DimensionNode("Honesty")
honesty.description="Discriminates between benign (White Hat attackers or ``honest but curious'') and malicious attackers (Black Hat). This dimension could also be used to define attackers that uses tools, e.g., jammers to protect the system or to detect intrusions"
honesty.metric=m_honesty
honesty.metricType=m_honesty
honesty.uniqueID=6
psychology.addChild(honesty)

camouflage=DimensionNode("Camouflage")
camouflage.description="Expresses the aim and/or the ability of the attacker to not be tracked down after or while performing an attack" 
camouflage.metric=m_visibility
camouflage.metricType=m_visibility
camouflage.uniqueID=7
psychology.addChild(camouflage)

determination=DimensionNode("Determination")
determination.description="Defines how long the attacker will perform the attacks on the system. As an example, the effort of the attacker should grow after each assessment performed on a system"
determination.metric=m_determination
determination.metricType=m_determination
determination.uniqueID=8
psychology.addChild(determination)

strategy=DimensionNode("Strategy")
strategy.description="Refers to the attack strategy adopted by the attacker. Random if an attacker will randomly select some attacks or some attack patterns. Brute-force when the attacker tries all possible attack pattern and structured when an optimal subset of attack patter is chosen"
strategy.metric=m_strategy
strategy.metricType=m_strategy
strategy.uniqueID=9
psychology.addChild(strategy)

#aim=DimensionNode("Aim")
#aim.description="Identifies which physical and logical parts of the target are more likely to be attacked by a certain attacker profile"
#aim.metric=m_aim
#aim.metricType=m_aim
#psychology.addChild(aim)
aimphysical=DimensionNode("Aim-Physical")
aimphysical.description="Represent the objective of the attacker with respect to physical components"
aimphysical.metric=m_aim
aimphysical.metricType=m_aim
aimphysical.uniqueID=10
psychology.addChild(aimphysical)

aimvirtual=DimensionNode("Aim-Virtual")
aimvirtual.description="Represent the objective of the attacker with respect to physical components"
aimvirtual.metric=m_aim
aimvirtual.metricType=m_aim
aimvirtual.uniqueID=11
psychology.addChild(aimvirtual)

periodicity=DimensionNode("Periodicity")
periodicity.description="Defines which is the frequency with which an attacker will try to attack the system. Some system are more incline to be attacked than other, for example, if a CPS is exposed on the Internet the periodicity of attacks will be higher with respect to a CPS isolated from the Internet"
periodicity.metric=m_periodicity
periodicity.metricType=m_periodicity
periodicity.uniqueID=12
psychology.addChild(periodicity)

#################
# 2*SUB DIMENSIONS 
#################
# ATTACK KNOWLEDGE
software=DimensionNode("Software")
software.description=""
software.metric=m_expertise
software.metricType=m_expertise
software.uniqueID=13
offensive.addChild(software)

network=DimensionNode("Network")
network.description=""
network.metric=m_expertise
network.metricType=m_expertise
network.uniqueID=14
offensive.addChild(network)

physical=DimensionNode("Physical")
physical.description=""
physical.metric=m_expertise
physical.metricType=m_expertise
physical.uniqueID=15
offensive.addChild(physical)

# SYSTEM KNOWLEDGE
sourceCode=DimensionNode("Source code")
sourceCode.description=""
sourceCode.metric=m_attackBox
sourceCode.metricType=m_attackBox
sourceCode.uniqueID=16
systemKnowledge.addChild(sourceCode)

protocols=DimensionNode("Protocols")
protocols.description=""
protocols.metric=m_attackBox
protocols.metricType=m_attackBox
protocols.uniqueID=17
systemKnowledge.addChild(protocols)

credentials=DimensionNode("Credentials") 
credentials.description=""
credentials.metric=m_access  
credentials.metricType=m_access
credentials.uniqueID=18
systemKnowledge.addChild(credentials)

# RESOURCES
distance=DimensionNode("Distance")
distance.description="Expresses the physical distance of the attacker with respect to the target and may limit his interactions with the system. This is particularly important with respect to CPS which can be isolated from the Internet or when using Wi-Fi networks"
distance.metric=m_distance
distance.metricType=m_distance
distance.uniqueID=19
resources.addChild(distance)

financial=DimensionNode("Financial support")
financial.description="Expresses which is the budget that an attacker has in order to perform an attack. Discriminating between attacker with low or high budget can be helpful, e.g., for risk assessments"
financial.metric=m_level
financial.metricType=m_level
financial.uniqueID=20
resources.addChild(financial)

effort=DimensionNode("Effort") 
effort.description="defines the effort an attacker will put into his attacks. How deeply the attacker will explore possible attacks and different ways to attack the system"
effort.metric=m_level
effort.metricType=m_level
effort.uniqueID=21
resources.addChild(effort)


manpower=DimensionNode("Manpower") 
manpower.description="Represents the human resources available to the attacker. This can be used to distinguish between lone attackers and (small to large) groups"
manpower.metric=m_level
manpower.metricType=m_level
manpower.uniqueID=22
resources.addChild(manpower)

tools=DimensionNode("Tools") 
tools.description="Also know as attacklets, defines which types of tools are available to the attacker for performing the attack"
tools.metric=m_expertise
tools.metricType=m_expertise
tools.uniqueID=23
resources.addChild(tools)

# AIM 
confidentiality=DimensionNode("Confidentiality")
confidentiality.description=""
confidentiality.metric=m_aim
confidentiality.metricType=m_aim
confidentiality.uniqueID=24
aimphysical.addChild(confidentiality)

confidentiality1=DimensionNode("Confidentiality")
confidentiality1.description=""
confidentiality1.metric=m_aim
confidentiality1.metricType=m_aim
confidentiality1.uniqueID=25
aimvirtual.addChild(confidentiality1)

integrity=DimensionNode("Integrity")
integrity.description=""
integrity.metric=m_aim
integrity.metricType=m_aim
integrity.uniqueID=26
aimphysical.addChild(integrity)
integrity1=DimensionNode("Integrity")
integrity1.description=""
integrity1.metric=m_aim
integrity1.metricType=m_aim
integrity1.uniqueID=27
aimvirtual.addChild(integrity1)

availabity=DimensionNode("Availability")
availabity.description=""
availabity.metric=m_aim
availabity.metricType=m_aim
availabity.uniqueID=28
aimphysical.addChild(availabity)
availabity1=DimensionNode("Availability")
availabity1.description=""
availabity1.metric=m_aim
availabity1.metricType=m_aim
availabity1.uniqueID=29
aimvirtual.addChild(availabity1)


###############################
#Attacker Model
#defined as a set of dimensions
###############################

attackerModel=AttackerTree('Attacker Model')
attackerModel.default=1
attackerModel.addChild(resources)
attackerModel.addChild(knowledge)
attackerModel.addChild(psychology)

#list of attacker models
attackerModels=[]
#list of our attacker profiles
attackerProfilesNames_our=['BasicUser','Cybercriminal','Hacktivist','Insider','NationState','Terrorist']
#list of frameworks
frameworks=[]

## Program run
sys.stdout.write(os.popen('clear').read()) # clear screen 
print "attackerModels and literature are the default directory"

#load the existing attacker models
menu_loadAttackerModels()
menu_loadFrameworks()


#create three lists:
#  attackerModels = all attackerModels
#  attackerModels_our = our attacker models
#  attackerModels_other = not ours :)
attackerModels_other=[]
attackerModels_our=[]

#mapping_profile_toremove=[{'name':'CardenasOverview_Cybercriminal','mapping':'cybercriminal'},{'name':'CardenasOverview_Insider','mapping':'insider'},{'name':'CardenasOverview_NationState','mapping':'nationstate'},{'name':'CardenasOverview_Terrorist','mapping':'terrorist'},{'name':'CormanAdaptivePersistent','mapping':'nationstate'},{'name':'CormanHacktivist','mapping':'hacktivist'},{'name':'CormanOrganizedCrime','mapping':'cybercriminal'},{'name':'CormanSkiddie','mapping':'basicuser'},{'name':'DolevYao','mapping':'cybercriminal'},{'name':'Heckman_Hacktivist','mapping':'hacktivist'},{'name':'Heckman_Hobbyist','mapping':'basicuser'},{'name':'Heckman_Insider','mapping':'insider'},{'name':'Heckman_NationState','mapping':'nationstate'},{'name':'Heckman_OrganizedCrime','mapping':'cybercriminal'},{'name':'Heckman_ScriptKiddie','mapping':'basicuser'},{'name':'Heckman_StructuredHacker','mapping':'cybercriminal'},{'name':'Heckman_Terrorist','mapping':'terrorist'},{'name':'Heckman_UnstructuredHacker','mapping':'basicuser'},{'name':'LeMay_DisgruntledEmployee','mapping':'insider'},{'name':'LeMay_LoneHacker','mapping':'cybercriminal'},{'name':'LeMay_NationState','mapping':'nationstate'},{'name':'LeMay_SystemAdministrator','mapping':'insider'},{'name':'LeMay_Terrorist','mapping':'terrorist'},{'name':'Urbina_Insider','mapping':'insider'}] 

our=False
for all_attackerModel in attackerModels:
    for our_attackerProfileName in attackerProfilesNames_our:
	if all_attackerModel.name.lower() == our_attackerProfileName.lower():
	    attackerModels_our.append(all_attackerModel)
	    our=True
    if our == False:
	attackerModels_other.append(all_attackerModel)
    our=False

menuOpt=0
while menuOpt == 0:
    menuOpt = getMenu() 
     
